import java.io.IOException;

public interface Helper {
    int Check(String strNum) throws IOException;
    Boolean isNumber(String str);
}
