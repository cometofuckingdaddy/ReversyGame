import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Desk implements Printable, Helper {
    private int retPlayer1 = 0;
    private int retPlayer2 = 0;
    private int pla1 = 0;
    private int pla2 = 0;
    private int numXofMove = 0;
    private int numYofMove = 0;
    private final ArrayList<String> strokes = new ArrayList<>();
    private static int player1 = 0;
    private static int player2 = 0;
    private final int[][] nullDesk = new int[8][8];

    public void PullDesk() {
        for (int i = 0; i < nullDesk.length; i++) {
            for (int j = 0; j < nullDesk.length; j++) {
                nullDesk[i][j] = 0;
            }
        }
        nullDesk[3][3] = 1;
        nullDesk[3][4] = 2;
        nullDesk[4][3] = 2;
        nullDesk[4][4] = 1;

    }

    public void print() {
        CheckForStrokes(1,2);
        System.out.println("◉ - White");
        System.out.println("○ - Black");
        System.out.println("x - Possible Move");
        System.out.println("   1 2 3 4 5 6 7 8");
        System.out.print("   - - - - - - - -" + "\n");
        int nums = 1;
        for (int i = 0; i < nullDesk.length; i++) {
            System.out.print(nums + "|");
            for (int j = 0; j < nullDesk.length; j++) {
                if (nullDesk[i][j] == 1) {
                    System.out.print(" " + "◉");
                }
                if (nullDesk[i][j] == 2) {
                    System.out.print(" " + "○");
                }
                if (nullDesk[i][j] == 0) {
                    boolean flag = false;
                    for (int k = 0; k < strokes.size(); k++) {
                        int numXforStroke = Integer.parseInt(String.valueOf(strokes.get(k).charAt(0))) - 1;
                        int numYforStroke = Integer.parseInt(String.valueOf(strokes.get(k).charAt(2))) - 1;
                        if (i == numXforStroke && j == numYforStroke) {
                            flag = false;
                            break;
                        } else {
                            flag = true;
                        }
                    }
                    if (!flag) {
                        System.out.print(" " + "x");
                    } else {
                        System.out.print(" " + "•");
                    }

                }

            }
            System.out.print("\n");
            nums++;
        }
        System.out.println("Moves available to you:");
        System.out.println("row x column");
        for (int i = 0; i < strokes.size(); i++) {
            System.out.print((i + 1) + ")");
            System.out.println(strokes.get(i));
        }

    }

    public boolean CheckForEnd() {
        for (int[] ints : nullDesk) {
            for (int j = 0; j < nullDesk.length; j++) {
                if (ints[j] == 1) {
                    player1 += 1;
                }
                if (ints[j] == 2) {
                    player2 += 1;
                }
            }
        }

        System.out.print("White player score:" + player1);
        System.out.print(" ; ");
        System.out.println("Black player score:" + player2);
        int pl1 = player1;
        int pl2 = player2;
        pla1 = pl1;
        pla2 = pl2;
        player1 = 0;
        player2 = 0;
        if (pl1 + pl2 == 64) {
            retPlayer1 = pl1;
            retPlayer2 = pl2;
            if (pl1 > pl2) {
                System.out.println("WHITE WON!");
            } else if (pl2 > pl1) {
                System.out.println("BLACK WON");
            } else if (pl1 == 32 && pl2 == 32) {
                System.out.println("DRAW");
            }
            return true;
        }
        return false;
    }
    public int Check(String strNum) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (!isNumber(strNum) || strNum.isEmpty()) {
            System.out.println("Its not a number, please input again" + "\n");
            strNum = reader.readLine();
        }
        int num = Integer.parseInt(strNum);
        while (num < 1 || num > strokes.size()) {
            System.out.println("Number less than 1 or more than available quantity, please input again");
            strNum = reader.readLine();
            num = Check(strNum);
        }
        return num;
    }

    public Boolean isNumber(String str) {
        boolean isOnlyDigits = true;
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                isOnlyDigits = false;
            }
        }
        return isOnlyDigits;
    }
    public ArrayList<Integer> LeaderBord() {
        ArrayList<Integer> leader = new ArrayList<>();
        leader.add(retPlayer1);
        leader.add(retPlayer2);
        return leader;
    }
public void MoveOfYourselfBlackForPlVsPl() throws IOException {
    System.out.println("Black player it's your turn!");
    System.out.println("Enter the number of the move you want to go to: \n");
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    if (strokes.size() != 0) {
        String strNum = reader.readLine();
        int num = Check(strNum);
        String ans = strokes.get(num - 1);
        numXofMove = Integer.parseInt(String.valueOf(ans.charAt(0))) - 1;
        numYofMove = Integer.parseInt(String.valueOf(ans.charAt(2))) - 1;
        nullDesk[numXofMove][numYofMove] = 2;
        ChangeColors(2,1);
    } else {
        if (CheckForStrokes(2,1)) {
            MoveOfYourselfWhiteForPlVsPl();
            print();
            MoveOfYourselfBlackForPlVsPl();
        } else {
            CheckForEnd();
            if (pla1 > pla2) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("WHITE WON!");
            } else if (pla2 > pla1) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("BLACK WON");
            } else if (pla1 == 32 && pla2 == 32) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("DRAW");
            }
        }
    }

}
public void MoveOfYourselfWhiteForPlVsPl() throws IOException {
        CheckForStrokes(2,1);

    int nums = 1;
    System.out.println("◉ - White");
    System.out.println("○ - Black");
    System.out.println("• - Possible Move");
    System.out.println("   1 2 3 4 5 6 7 8");
    System.out.print("   - - - - - - - -" + "\n");
    for (int i = 0; i < nullDesk.length; i++) {
        System.out.print(nums + "|");
        for (int j = 0; j < nullDesk.length; j++) {
            if (nullDesk[i][j] == 1) {
                System.out.print(" " + "◉");
            }
            if (nullDesk[i][j] == 2) {
                System.out.print(" " + "○");
            }
            if (nullDesk[i][j] == 0) {
                boolean flag = false;
                for (int k = 0; k < strokes.size(); k++) {
                    int numXforStroke = Integer.parseInt(String.valueOf(strokes.get(k).charAt(0))) - 1;
                    int numYforStroke = Integer.parseInt(String.valueOf(strokes.get(k).charAt(2))) - 1;
                    if (i == numXforStroke && j == numYforStroke) {
                        flag = false;
                        break;
                    } else {
                        flag = true;
                    }
                }
                if (!flag) {
                    System.out.print(" " + "x");
                } else {
                    System.out.print(" " + "•");
                }

            }

        }
        System.out.print("\n");
        nums++;
    }

    System.out.println("White player it's your turn!");
    System.out.println("Enter the number of the move you want to go to: \n");
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    System.out.println("Moves available to you:");
    System.out.println("row x column");
    for (int i = 0; i < strokes.size(); i++) {
        System.out.print((i + 1) + ")");
        System.out.println(strokes.get(i));
    }
    if (strokes.size() != 0) {
        String strNum = reader.readLine();
        int num = Check(strNum);
        String ans = strokes.get(num - 1);
        numXofMove = Integer.parseInt(String.valueOf(ans.charAt(0))) - 1;
        numYofMove = Integer.parseInt(String.valueOf(ans.charAt(2))) - 1;
        nullDesk[numXofMove][numYofMove] = 1;
        ChangeColors(1,2);
    } else {
        if (CheckForStrokes(1,2)) {
            MoveOfYourselfBlackForPlVsPl();
            print();
            MoveOfYourselfWhiteForPlVsPl();
        } else {
            CheckForEnd();
            if (pla1 > pla2) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("WHITE WON!");
            } else if (pla2 > pla1) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("BLACK WON");
            } else if (pla1 == 32 && pla2 == 32) {
                retPlayer1 = pla1;
                retPlayer2 = pla2;
                System.out.println("DRAW");
            }
        }
    }

}
    public void MoveOfYourself() throws IOException {
        CheckForStrokes(1,2);
        System.out.println("Black player it's your turn!");
        System.out.println("Enter the number of the move you want to go to: \n");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        if (strokes.size() != 0) {
            String strNum = reader.readLine();
            int num = Check(strNum);
            String ans = strokes.get(num - 1);
            numXofMove = Integer.parseInt(String.valueOf(ans.charAt(0))) - 1;
            numYofMove = Integer.parseInt(String.valueOf(ans.charAt(2))) - 1;
            nullDesk[numXofMove][numYofMove] = 2;
            ChangeColors(2,1);
        } else {
            if (CheckStrokesForComputer()) {
                MoveOfComputer();
                print();
                MoveOfYourself();
            } else {
                CheckForEnd();
                if (pla1 > pla2) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("WHITE WON!");
                } else if (pla2 > pla1) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("BLACK WON");
                } else if (pla1 == 32 && pla2 == 32) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("DRAW");
                }
            }
        }
    }

    public void MoveOfComputer() throws IOException {
        if (CheckStrokesForComputer()) {
            int rand = (int) (Math.random() * strokes.size());
            numXofMove = Integer.parseInt(String.valueOf(strokes.get(rand).charAt(0))) - 1;
            numYofMove = Integer.parseInt(String.valueOf(strokes.get(rand).charAt(2))) - 1;
        } else {
            if (CheckForStrokes(1,2)) {
                MoveOfYourself();
                MoveOfComputer();
            } else {
                CheckForEnd();
                if (pla1 > pla2) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("WHITE WON!");
                } else if (pla2 > pla1) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("BLACK WON");
                } else if (pla1 == 32 && pla2 == 32) {
                    retPlayer1 = pla1;
                    retPlayer2 = pla2;
                    System.out.println("DRAW");
                }
            }
        }
        nullDesk[numXofMove][numYofMove] = 1;
        ChangeColors(1,2);
        strokes.clear();
    }

    private boolean CheckStrokesForComputer() {
        CheckForStrokes(2,1);
        if (strokes.size() == 0) {
            System.out.println("Computer haven't moves");
            System.out.println("Move go to YOU!");
            return false;
        }
        return true;
    }

    private boolean CheckForStrokes(int n, int m) {
        for (int i = 0; i < nullDesk.length; i++) {
            for (int j = 0; j < nullDesk.length; j++) {
                if (nullDesk[i][j] == m) {
                    int methodXnum = i;
                    int methodYnum = j;
                    if (methodXnum == 0 && methodYnum == 0) {
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n){
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum == 7 && methodYnum == 0) {
                        --methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum == 0 && methodYnum == 7) {
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum == 7 && methodYnum == 7) {
                        --methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum == 0) {
                        if (methodYnum > 0) {
                            --methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (methodYnum > 0) {
                            --methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (methodYnum < 7) {
                            ++methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        if (methodYnum < 7) {
                            ++methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodYnum == 0 && methodXnum != 0 && methodXnum != 7) {
                        --methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum == 7) {
                        if (methodYnum > 0) {
                            --methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        if (methodYnum > 0) {
                            --methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        if (methodYnum < 7) {
                            ++methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        if (methodYnum < 7) {
                            ++methodYnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodYnum == 7) {
                        if (methodXnum > 0) {
                            --methodXnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        if (methodXnum > 0) {
                            --methodXnum;
                        }
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        if (methodXnum < 7) {
                            ++methodXnum;
                        }
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        if (methodXnum < 7) {
                            ++methodXnum;
                        }
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                    if (methodXnum > 0 && methodXnum < 7 && methodYnum > 0 && methodYnum < 7) {
                        --methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        ++methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                ++methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        ++methodXnum;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum < 7 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                ++methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                        --methodXnum;
                        --methodYnum;
                        if (nullDesk[methodXnum][methodYnum] == n) {
                            while (methodXnum > 0 && methodYnum > 0 && nullDesk[methodXnum][methodYnum] == n) {
                                --methodXnum;
                                --methodYnum;
                            }
                            if (nullDesk[methodXnum][methodYnum] == 0) {
                                if (!strokes.contains((methodXnum + 1) + "x" + (methodYnum + 1))) {
                                    strokes.add((methodXnum + 1) + "x" + (methodYnum + 1));
                                }
                            }
                        }
                        methodXnum = i;
                        methodYnum = j;
                    }
                }
            }
        }
        if (strokes.size() == 0) {
            System.out.println("You haven't moves");
            System.out.println("Move go to Computer");
            return false;
        }
        return true;
    }

    public void ChangeColors(int n, int m) {
        ArrayList<Integer> X = new ArrayList<>();
        ArrayList<Integer> Y = new ArrayList<>();
        int methodXnum = numXofMove;
        int methodYnum = numYofMove;

        if (methodXnum == 0 && methodYnum == 0) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum <= 7 && nullDesk[++methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum == 7 && methodYnum == 0) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum < 7 && nullDesk[--methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum == 0 && methodYnum == 7) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum > 0 && nullDesk[++methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum == 7 && methodYnum == 7) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum > 0 && nullDesk[--methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum == 0) {
            if (nullDesk[numXofMove][numYofMove] == n) {
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum > 0 && nullDesk[++methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum < 7 && nullDesk[++methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodYnum == 0) {
            if (nullDesk[numXofMove][numYofMove] == n) {
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum < 7 && nullDesk[--methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum < 7 && nullDesk[++methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum == 7) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum > 0 && nullDesk[--methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum < 7 && nullDesk[--methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodYnum == 7) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum > 0 && nullDesk[--methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum > 0 && nullDesk[++methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        if (methodXnum > 0 && methodXnum < 7 && methodYnum > 0 && methodYnum < 7) {
            if (nullDesk[methodXnum][methodYnum] == n) {
                while (methodXnum > 0 && nullDesk[--methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum < 7 && nullDesk[--methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum < 7 && nullDesk[methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum < 7 && nullDesk[++methodXnum][++methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && nullDesk[++methodXnum][methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum < 7 && methodYnum > 0 && nullDesk[++methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodYnum > 0 && nullDesk[methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
                while (methodXnum > 0 && methodYnum > 0 && nullDesk[--methodXnum][--methodYnum] == m) {
                    X.add(methodXnum);
                    Y.add(methodYnum);
                }
                if (nullDesk[methodXnum][methodYnum] == n) {
                    for (int i = 0; i < X.size(); ) {
                        for (int j = 0; j < Y.size(); j++) {
                            nullDesk[X.get(i)][Y.get(j)] = n;
                            i++;
                        }
                    }
                }
                X.clear();
                Y.clear();
                methodXnum = numXofMove;
                methodYnum = numYofMove;
            }
        }
        strokes.clear();
    }
}
