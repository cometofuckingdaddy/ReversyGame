import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.IllegalFormatCodePointException;

public class Main {
    static ArrayList<Integer> leaderBlack = new ArrayList<>();
    static ArrayList<Integer> leaderWhite = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        Menu();
    }


    private static void Helper() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("1. Player VS Computer");
        System.out.println("2. Player VS Player");
        System.out.println("\n");
        System.out.println("Choose one of them");
        String strNum = reader.readLine();
        int num = Check(strNum);
        if (num == 1) {
            Desk mode1 = new Desk();
            mode1.PullDesk();
            mode1.print();
            while (!mode1.CheckForEnd()) {
                mode1.MoveOfYourself();
                if (mode1.CheckForEnd()) {
                    break;
                }
                mode1.MoveOfComputer();
                mode1.print();
            }
            ArrayList<Integer> leaderBord = mode1.LeaderBord();
            if (!leaderWhite.contains(leaderBord.get(0))) {
                if (leaderWhite.size() != 0) {
                    if (leaderWhite.get(0) < leaderBord.get(0)) {
                        leaderWhite.clear();
                        leaderWhite.add(leaderBord.get(0));
                    }
                }
                if (leaderWhite.size() == 0) {
                    leaderWhite.add(leaderBord.get(0));
                }
            }
            if (!leaderBlack.contains(leaderBord.get(1))) {
                if (leaderBlack.size() != 0) {
                    if (leaderBlack.get(0) < leaderBord.get(1)) {
                        leaderBlack.clear();
                        leaderBlack.add(leaderBord.get(1));
                    }
                }
                if (leaderBlack.size() == 0) {
                    leaderBlack.add(leaderBord.get(1));
                }
            }


        } else if (num == 2) {
            Desk mode2 = new Desk();
            mode2.PullDesk();
            mode2.print();
            while (!mode2.CheckForEnd()) {
                mode2.MoveOfYourselfBlackForPlVsPl();
                if (mode2.CheckForEnd()) {
                    break;
                }
                mode2.MoveOfYourselfWhiteForPlVsPl();
                mode2.print();
            }
            ArrayList<Integer> leaderBord = mode2.LeaderBord();
            if (!leaderWhite.contains(leaderBord.get(0))) {
                if (leaderWhite.size() != 0) {
                    if (leaderWhite.get(0) < leaderBord.get(0)) {
                        leaderWhite.clear();
                        leaderWhite.add(leaderBord.get(0));
                    }
                }
                if (leaderWhite.size() == 0) {
                    leaderWhite.add(leaderBord.get(0));
                }
            }
            if (!leaderBlack.contains(leaderBord.get(1))) {
                if (leaderBlack.size() != 0) {
                    if (leaderBlack.get(0) < leaderBord.get(1)) {
                        leaderBlack.clear();
                        leaderBlack.add(leaderBord.get(1));
                    }
                }
                if (leaderBlack.size() == 0) {
                    leaderBlack.add(leaderBord.get(0));
                }
            }
        }
        System.out.println("Do you want to play again? input y/Y to restart");
        System.out.println("If you want to exit game, write something different");
        String answ = reader.readLine();
        if (answ.equals("y") || answ.equals("Y")) {
            Menu();
        }
        System.exit(0);
    }
public static void LeaderBoard() {
    System.out.println("\n");
    System.out.println("LEADERBOARD FOR ONE SESSION");
    if (leaderWhite.size() == 0 || leaderBlack.size() == 0) {
        System.out.println("You haven't played yet");
    } else {
        System.out.println("The best result of Black: " + leaderBlack.get(0));
        System.out.println("The best result of White: " + leaderWhite.get(0));
    }
}
    public static int Check(String strNum) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (!isNumber(strNum) || strNum.isEmpty()) {
            System.out.println("Its not a number, please input again" + "\n");
            strNum = reader.readLine();
        }
        int num = Integer.parseInt(strNum);
        while (num != 1 && num != 2) {
            System.out.println("No such option, try again!");
            strNum = reader.readLine();
            num = Integer.parseInt(strNum);
        }
        return num;
    }

    private static Boolean isNumber(String str) {
        boolean isOnlyDigits = true;
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                isOnlyDigits = false;
            }
        }
        return isOnlyDigits;
    }

    private static void Menu() throws IOException {
        Menu menu = new Menu();
        menu.print();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String strNum = reader.readLine();
        int num = menu.Check(strNum);
        if (num == 1) {
            Helper();
        } else if (num == 2) {
            System.out.println("В игре используется квадратная доска размером 8 × 8 клеток (все клетки могут быть одного" +
                    " цвета) и 64 специальные фишки, окрашенные с разных сторон в контрастные цвета, например, в белый и " +
                    "чёрный.");
            System.out.println("Клетки доски нумеруются от верхнего левого угла: вертикали — латинскими " +
                    "буквами, горизонтали — цифрами (по сути дела, можно использовать шахматную доску). Один из " +
                    "игроков " +
                    "играет белыми, другой — чёрными. Делая ход, игрок " +
                    "ставит фишку на клетку доски «своим» цветом вверх.");
            System.out.println("В начале игры в центр доски выставляются 4 фишки: чёрные " +
                    "на 4x4 и 5x5, белые на 4x5 и 5x4.");
            System.out.println("Первый ход делают чёрные. Далее игроки ходят по очереди.\n" +
                    "Делая ход, игрок должен поставить свою фишку на одну из клеток доски таким образом, чтобы между" +
                    " этой поставленной " +
                    "фишкой и одной из имеющихся уже на доске фишек его цвета находился непрерывный ряд " +
                    "фишек соперника, горизонтальный, " +
                    "вертикальный или диагональный (другими словами, чтобы непрерывный ряд фишек соперника " +
                    "оказался «закрыт» фишками игрока с двух сторон). Все фишки соперника, входящие в «закрытый» " +
                    "на этом ходу ряд, переворачиваются на другую сторону (меняют цвет) и переходят к ходившему игроку.");

            System.out.println("Если в результате одного хода «закрывается» одновременно более одного ряда фишек " +
                    "противника, то переворачиваются все фишки, оказавшиеся на тех «закрытых» рядах, которые идут от " +
                    "поставленной фишки.");
            System.out.println("Игрок вправе выбирать любой из возможных для него ходов. Если игрок имеет возможные " +
                    "ходы, он не может отказаться от хода. Если игрок не имеет допустимых ходов, то ход передаётся " +
                    "сопернику.");
            System.out.println("Игра прекращается, когда на доску выставлены все фишки или когда ни один из игроков не " +
                    "может сделать хода. По окончании игры проводится подсчёт фишек каждого цвета, и игрок, чьих фишек " +
                    "на доске выставлено больше, объявляется победителем. В случае равенства количества фишек " +
                    "засчитывается ничья.");
            Menu();
        } else if (num == 3) {
            LeaderBoard();
            Menu();
        } else if (num == 4) {
            System.exit(0);
        }
    }
}