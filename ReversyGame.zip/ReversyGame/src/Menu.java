import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Menu implements Helper, Printable{


    @Override
    public int Check(String strNum) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (!isNumber(strNum) || strNum.isEmpty()) {
            System.out.println("Its not a number, please input again" + "\n");
            strNum = reader.readLine();
        }
        int num = Integer.parseInt(strNum);
        while (num < 1 || num > 4) {
            System.out.println("No such option");
            strNum = reader.readLine();
            num = Check(strNum);
        }
        return num;
    }

    @Override
    public Boolean isNumber(String str) {
        boolean isOnlyDigits = true;
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                isOnlyDigits = false;
            }
        }
        return isOnlyDigits;
    }

    @Override
    public void print() {
        System.out.println("1.Choose mode and play");
        System.out.println("2.Rules");
        System.out.println("3.LeaderBoard");
        System.out.println("4.Exit");
    }
}
